import math

def venturi_mass_flow_rate(d1, d2, h1, h2, rho_man, rho_air, T, Cd=0.98, gamma=1.4, R=287):
    # Pressure difference from manometer (Pa)
    delta_h = h1 - h2
    dp = (rho_man - rho_air) * 9.81 * delta_h  

    # Area at inlet and throat
    A1 = math.pi * (d1**2) / 4
    A2 = math.pi * (d2**2) / 4
    beta = d2/d1

    # Expansibility factor epsilon (ISO 5167 approximation)
    # For gases with moderate pressure drop:
    tau = (1 - dp / (rho_air * R * T))  # pressure ratio approx
    if tau <= 0: tau = 0.0001
    eps = tau**(1/gamma) / math.sqrt(tau * (1 - tau**((gamma-1)/gamma)) / (1 - tau))

    # Volumetric flow rate (incompressible assumption)
    Q_incomp = Cd * A2 * math.sqrt( (2*dp) / (rho_air * (1 - beta**4)) )

    # Corrected for compressibility
    Q_gas = eps * Q_incomp  

    # Mass flow rate
    m_dot = rho_air * Q_gas  

    return m_dot

# Example usage
if __name__ == "__main__":
    d1 = 0.04   # 5 cm inlet diameter
    d2 = 0.02  # 2.5 cm throat diameter
    h1 = 0.20   # 20 cm column
    h2 = 0.15   # 15 cm column
    rho_man = 1000  # water density (kg/m^3)
    rho_air = 1.2   # density of air (kg/m^3)
    T = 300         # 300 K (~27 °C)

    m_dot = venturi_mass_flow_rate(d1, d2, h1, h2, rho_man, rho_air, T)
    print(f"Mass flow rate = {m_dot:.4f} kg/s")