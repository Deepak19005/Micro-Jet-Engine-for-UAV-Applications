import math as m
Thrust = 300
T_com = 1000  #Based on Material constraints
# Air properties at 1000K:
cv = 848.92617
cp = 1136.11517
cp_room = 1005

gamma = cp/cv
R = cp-cv
rho = 0.35282
p_atm = 1.01325*pow(10,5)
com_ratio = 1.61
fuel_mix_ratio = 1/50 # For temperature not to exceed 1200 K
LHV = 43.1*pow(10,6)

v_in = 0
v_nozzle = 250   #this velocity should not cross speed of sound
mdot_nozzle = (Thrust)/v_nozzle
mdot_in = mdot_nozzle/(1+fuel_mix_ratio)
p_nozzle = p_atm   #to maximize the thrust, we should decrease the pressure and increase the velocity
p_comp_out = com_ratio*p_atm

p_0 = p_nozzle + (0.5*rho*pow(v_nozzle,2))
T_0 = T_com+(v_nozzle/(2*cp))
A_nozzle = (mdot_nozzle/p_0)*pow(((R*T_0/gamma)*pow((gamma/2+0.5),((gamma+1)/(gamma-1)))),0.5)
# A_nozzle = (Thrust-(mdot_nozzle*v_nozzle)+((mdot_in)(v_in)))/(p_nozzle-p_atm)
p_comb_end = p_comp_out
eff_comb = (mdot_in*(T_com*cp-300*cp_room))/(mdot_in*fuel_mix_ratio*LHV)
m_dot = (2*m.pi*)
#A_comb = mdot_nozzle/(rho*v_comb)


print("Required mass flow rate(in) is : " + str(mdot_in) + " Kg/s")
print("Required mass flow rate(out) is : " + str(mdot_nozzle) + " Kg/s")
print("A_nozzle(Area of Nozzle or Exhaust) : " + str(A_nozzle) + " m^2 or Diameter(" + (str(pow(((4/3.14)*(A_nozzle)),0.5))) + " m)")
print("Efficiency of combustion chamber : " + str(eff_comb))




