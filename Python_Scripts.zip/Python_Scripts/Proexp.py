import numpy as np
import matplotlib.pyplot as plt
import math as m

# Given constants
cp = 1001
T_in = 300  # Inlet temperature (K)
gamma = 1.402
beta2 = np.radians(30)  # Blade exit angle
rho_T_0 = 0.7  # Air density at stagnation condition
n_imp = 0.7  # Impeller efficiency
slip_factor = 0.8  # Practical slip factor
v_in = 7.5  # Inlet velocity (m/s)

# Blade dimensions (converted from inches to meters)
dim_rat = 10 / 22.7838  # Dimension ratio
r1 = (2.87 * 2 / 2) * 0.0254 * dim_rat  # Inlet blade radius
r2 = (8.97 / 2) * 0.0254 * dim_rat  # Outlet blade radius
b1 = (2.67) * 0.0254 * dim_rat  # Blade height at inlet
b2 = (0.48) * 0.0254 * dim_rat  # Blade height at outlet
t1 = (0.02) * 0.0254 * dim_rat  # Blade thickness at inlet
n2 = 22  # Number of blades at exit

# RPM range (5000 to 40000)
N_values = np.linspace(50, 40000, 100)
rc_values = []

# Compute rc for varying RPM
for N in N_values:
    u2 = 2 * m.pi * N * r2 / 60  # Outlet blade velocity
    
    # Mass flow rate formula using given expression
    #m_dot = (1 - slip_factor) * rho_T_0 * (2 * m.pi * r2 - n2 * t1) * b2 * (u2 * m.tan(beta2))
    
    # Compute pressure ratio rc
    rc = pow(1 + (n_imp * slip_factor * u2 * (u2 - (((1 - slip_factor) * rho_T_0 * (2 * m.pi * r2 - n2 * t1) * b2 * (u2 * m.tan(beta2))) / (2 * m.pi * r2 * b2 * m.tan(beta2)))) /
                 ((T_in + (pow(v_in, 2) / (2 * cp))) * cp)), (gamma / (gamma - 1)))
    
    rc_values.append(rc)

# Convert to numpy arrays
rc_values = np.array(rc_values)

# Plot Pressure Ratio vs RPM
plt.figure(figsize=(8, 5))
plt.plot(N_values, rc_values, 'b', label=r'$r_c$ vs $N$')
plt.xlabel('RPM (N)')
plt.ylabel('Pressure Ratio $r_c$')
plt.title('Pressure Ratio vs RPM')
plt.legend()
plt.grid()
plt.show()
