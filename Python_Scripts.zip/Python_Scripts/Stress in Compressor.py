import math as math
rho = 0.00106
v = 0.38
omega = 20000
ri = 0.015
ro = 0.1
r = 0.075

Hoop_stress = rho*pow(omega,2)*((3+v)/(8))*(pow(ri,2)+pow(ro,2)+(pow(ri,2)*pow(ro,2)/pow(r,2))-((1+3*v)*(pow(r,2))/(3+v)))
Radial_stress = rho*pow(omega,2)*(pow(ri,2)+pow(ro,2)-(pow(ri,2)*pow(ro,2)/pow(r,2))-(pow(r,2)))

print("Hoop stress = "+str(Hoop_stress)+"Pa")
print("Radial stress = "+str(Radial_stress)+"Pa")